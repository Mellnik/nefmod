KFAntiBlocker by Benjamin
-------------------------

Copy both these files into your killingfloor\system folder, usually located at:

C:\Program Files\Steam\steamapps\common\

Enjoy!