SentryTech  (Sentry and High Tech Weapons Specialist)




Install:
I have broken the files down to the correct directories.
Perk Works with Marco's server perks



Copy files from each folder to the same folder in your killing floor directory.


Add to server perks
SentryTechPerkV111.SRVetSentryTechPerk


Add the following, to add the weapons
SentryTechWeapV111.TechDoomsentryBotPickup
SentryTechWeapV111.TechMedicSentryBotPickup
SentryTechWeapV111.TechPTurretPickup
SentryTechWeapV111.TechBioLauncherPickup
SentryTechWeapV111.TechShockRiflePickup
SentryTechWeapV111.TechIncendiaryPipeBombPickup
SentryTechWeapV111.TechMachinePistolPickup
SentryTechWeapV111.TechMachineDualiesPickup
SentryTechWeapV111.TechUSCMSentryPickup
SentryTechWeapV111.TechPipeBombPickup
SentryTechWeapV111.TechM7A3MPickup
SentryTechWeapV111.TechPlasmaCutterPickup
SentryTechWeapV111.TechG36CPickup
SentryTechWeapV111.TechHL_BlueGravityGunPickup
SentryTechWeapV111.TechHL_BugBaitPickup
SentryTechWeapV111.TechHL_GravityGunPickup
SentryTechWeapV111.TechHL_RPGPickup
SentryTechWeapV111.TechAdvancedWelderPickup
SentryTechWeapV111.TechFlaregun


Add the following to your killingfloor.ini file
ServerPackages=SentryTechWeapV111

With the current version, sorry for the large download.  The weapon source files are pulling from something from the KFLTex file.  I have nothing left in my code on the weapons that should pull from the KFLTex file, I have even checked the animation and static meshes, I have every fully switched. I'm guessing something is hidden??  For some reason the weapons will not compile without it. But for now, the KFLTex file is needed.  Everything is working as far as I know from some test runs. :D  I'm going to continue to look into why the KFLTex file is needed, so maybe in future updates it will be removed.  




The SentryTech is pretty much what it sounds :)  The perk specializes in Sentry bots and also high tech weapons.  The perks pros are, very fast movement and strong shields, that's pretty much it. However, the perk will need the speed and shield increase because what the perk has in high tech gagets, the perk lacks in defense.  The perk takes extra damage from everything, you name it, explosive, fire, bloat vomit, all attacks... The perk takes a lot of extra damage, and even at the end of the perk level, it still takes a lot of extra damage to everything.  So, that being said, use the perks fast speed to stay away from zeds and if you do get swarmed, just hope your shields will take the damage until you can escape. ;) 

The perk uses the Brutes point system, since I'm sure the bots will do a lot of damage. The bots have been modified in health and damage since the Sentry Tech specializes in well... High Tech weapons and gagets ;)

Hope you enjoy it :D

Thanks,
Guardian



I would also like to take this time to thank all the people that made the weapons I have placed in this perk. :)


I would like to thank the makers of the KFL Mod and also the makers of the weapons I have used in the perk.  The following were pulled out from the KFL Mod to be used in the perk :)  The two Sentry Bots, ShockRifle, Bio Launcher, Incendiary PipeBomb and the MachinePistols. :)

The the Portal Turret, I got that from download here on the forms, the maker is Marco.  Thank you Marco for making this sweet weapon :D

Again a HUGE THANKS to the makers of the weapons, with out those, the perk would not be possible. :D



Enjoy the perk :D  Happy Fragging those Zeds :D


